@echo off
cd /d "%~dp0"
node "%~dp0scout-phone.js" %*
